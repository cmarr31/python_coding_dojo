from __future__ import unicode_literals

from django.apps import AppConfig


class HelloWorld1Config(AppConfig):
    name = 'hello_world_1'
